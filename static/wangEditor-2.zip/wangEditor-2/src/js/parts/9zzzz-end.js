    
    // 最终返回wangEditor构造函数
    return window.wangEditor;
});